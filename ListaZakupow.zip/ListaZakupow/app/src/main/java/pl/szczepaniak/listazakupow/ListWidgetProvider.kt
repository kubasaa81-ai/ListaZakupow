package pl.szczepaniak.listazakupow

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.RemoteViews

class ListWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val id = intent.getLongExtra(EXTRA_ID, -1L)
            if (id >= 0) Store.toggle(context, id) // Store sam odswieza widzet
        }
    }

    companion object {
        const val ACTION_TOGGLE = "pl.szczepaniak.listazakupow.TOGGLE"
        const val EXTRA_ID = "item_id"

        @Suppress("DEPRECATION")
        fun update(ctx: Context, manager: AppWidgetManager, widgetId: Int) {
            val svc = Intent(ctx, ListWidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }
            val rv = RemoteViews(ctx.packageName, R.layout.widget_list)
            rv.setRemoteAdapter(R.id.widget_list, svc)
            rv.setEmptyView(R.id.widget_list, R.id.widget_empty)

            val immutable = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java), immutable
            )
            rv.setOnClickPendingIntent(R.id.widget_title, open)
            rv.setOnClickPendingIntent(R.id.widget_empty, open)

            val addIntent = Intent(ctx, MainActivity::class.java)
                .setAction("ADD_ITEM")
                .putExtra(MainActivity.EXTRA_FOCUS_ADD, true)
            rv.setOnClickPendingIntent(
                R.id.widget_add, PendingIntent.getActivity(ctx, 1, addIntent, immutable)
            )

            // klikniecie pozycji na liscie = odhaczenie (w koszyku) / cofniecie
            val mutable = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val toggle = Intent(ctx, ListWidgetProvider::class.java).setAction(ACTION_TOGGLE)
            rv.setPendingIntentTemplate(
                R.id.widget_list,
                PendingIntent.getBroadcast(
                    ctx, 2, toggle, PendingIntent.FLAG_UPDATE_CURRENT or mutable
                )
            )
            manager.updateAppWidget(widgetId, rv)
        }

        @Suppress("DEPRECATION")
        fun refreshAll(ctx: Context) {
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, ListWidgetProvider::class.java))
            if (ids.isNotEmpty()) manager.notifyAppWidgetViewDataChanged(ids, R.id.widget_list)
        }
    }
}

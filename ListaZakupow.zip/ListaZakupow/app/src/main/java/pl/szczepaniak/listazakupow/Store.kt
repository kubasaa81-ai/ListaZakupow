package pl.szczepaniak.listazakupow

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Item(val id: Long, var name: String, var checked: Boolean)

/** Przechowywanie listy i "pamieci" czesto kupowanych produktow (w telefonie, bez internetu). */
object Store {

    private fun prefs(c: Context) = c.getSharedPreferences("lista_zakupow", Context.MODE_PRIVATE)

    // ---------- LISTA ----------

    fun items(c: Context): MutableList<Item> {
        val arr = JSONArray(prefs(c).getString("items", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Item(o.getLong("id"), o.getString("name"), o.getBoolean("checked"))
        }.toMutableList()
    }

    /** Najpierw to, co do kupienia, potem to, co juz w koszyku. */
    fun sorted(c: Context): List<Item> = items(c).sortedBy { it.checked }

    private fun save(c: Context, list: List<Item>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("checked", it.checked))
        }
        prefs(c).edit().putString("items", arr.toString()).apply()
        ListWidgetProvider.refreshAll(c)
    }

    private fun nextId(c: Context): Long {
        val p = prefs(c)
        val id = p.getLong("nextId", 1L)
        p.edit().putLong("nextId", id + 1).apply()
        return id
    }

    private fun normalize(raw: String): String =
        raw.trim().replace(Regex("\\s+"), " ").replaceFirstChar { it.uppercase() }

    /** Zwraca true, gdy produkt zostal dodany jako nowa pozycja. */
    fun add(c: Context, raw: String): Boolean {
        val name = normalize(raw)
        if (name.isBlank()) return false
        val list = items(c)
        val existing = list.find { it.name.equals(name, ignoreCase = true) }
        if (existing != null) {
            if (existing.checked) {
                existing.checked = false
                save(c, list)
            }
            return false
        }
        list.add(Item(nextId(c), name, false))
        save(c, list)
        bumpFreq(c, name)
        return true
    }

    fun toggle(c: Context, id: Long) {
        val list = items(c)
        list.find { it.id == id }?.let { it.checked = !it.checked }
        save(c, list)
    }

    fun rename(c: Context, id: Long, newName: String) {
        val name = normalize(newName)
        if (name.isBlank()) return
        val list = items(c)
        list.find { it.id == id }?.let { it.name = name }
        save(c, list)
    }

    fun remove(c: Context, id: Long) {
        save(c, items(c).filter { it.id != id })
    }

    fun removeChecked(c: Context): Int {
        val list = items(c)
        val left = list.filter { !it.checked }
        save(c, left)
        return list.size - left.size
    }

    fun clearAll(c: Context) = save(c, emptyList())

    // ---------- CZESTO KUPOWANE ----------

    private fun freq(c: Context) = JSONObject(prefs(c).getString("freq", "{}"))
    private fun saveFreq(c: Context, o: JSONObject) =
        prefs(c).edit().putString("freq", o.toString()).apply()

    private fun entry(o: JSONObject, name: String): JSONObject {
        val k = name.lowercase()
        return o.optJSONObject(k) ?: JSONObject()
            .put("name", name).put("count", 0).put("fav", false)
            .also { o.put(k, it) }
    }

    private fun bumpFreq(c: Context, name: String) {
        val o = freq(c)
        val e = entry(o, name)
        e.put("count", e.optInt("count") + 1)
        saveFreq(c, o)
    }

    fun favorites(c: Context): Set<String> {
        val o = freq(c)
        val res = mutableSetOf<String>()
        o.keys().forEach { k -> if (o.getJSONObject(k).optBoolean("fav")) res.add(k) }
        return res
    }

    fun toggleFav(c: Context, name: String) {
        val o = freq(c)
        val e = entry(o, name)
        e.put("fav", !e.optBoolean("fav"))
        saveFreq(c, o)
    }

    fun forget(c: Context, name: String) {
        val o = freq(c)
        o.remove(name.lowercase())
        saveFreq(c, o)
    }

    /** Podpowiedzi: ulubione (gwiazdka) + kupione co najmniej 2 razy, ktorych teraz nie ma na liscie. */
    fun suggestions(c: Context): List<Pair<String, Boolean>> {
        val onList = items(c).filter { !it.checked }.map { it.name.lowercase() }.toSet()
        val o = freq(c)
        val res = mutableListOf<Triple<String, Int, Boolean>>()
        o.keys().forEach { k ->
            val e = o.getJSONObject(k)
            val fav = e.optBoolean("fav")
            val count = e.optInt("count")
            if (k !in onList && (fav || count >= 2)) res.add(Triple(e.getString("name"), count, fav))
        }
        return res.sortedWith(compareByDescending<Triple<String, Int, Boolean>> { it.third }
            .thenByDescending { it.second })
            .take(30)
            .map { it.first to it.third }
    }
}

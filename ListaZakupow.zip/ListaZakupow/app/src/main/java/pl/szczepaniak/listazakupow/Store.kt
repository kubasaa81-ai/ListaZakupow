package pl.szczepaniak.listazakupow

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

data class Item(val id: Long, var name: String, var checked: Boolean)
data class Shop(val id: Long, var name: String)

/**
 * Przechowywanie danych w telefonie (bez internetu):
 * - lista sklepow,
 * - osobna lista zakupow dla kazdego sklepu,
 * - osobna "pamiec" czesto kupowanych dla kazdego sklepu.
 */
object Store {

    private val DEFAULT_SHOPS = listOf("Lidl", "Biedronka", "Rossmann", "OBI", "Castorama")

    private val PALETTE = listOf(
        "#1565C0", "#D32F2F", "#C2185B", "#EF6C00", "#00838F",
        "#6A1B9A", "#2E7D32", "#5D4037", "#455A64", "#AD1457"
    )

    private fun prefs(c: Context) = c.getSharedPreferences("lista_zakupow", Context.MODE_PRIVATE)

    private fun newId(c: Context): Long {
        val p = prefs(c)
        val id = p.getLong("nextId", 1L)
        p.edit().putLong("nextId", id + 1).apply()
        return id
    }

    private fun normalize(raw: String): String =
        raw.trim().replace(Regex("\\s+"), " ").replaceFirstChar { it.uppercase() }

    // =====================================================================
    // SKLEPY
    // =====================================================================

    fun shops(c: Context): MutableList<Shop> {
        val p = prefs(c)
        val raw = p.getString("shops", null)
        if (raw == null) {
            // pierwsze uruchomienie (lub aktualizacja z wersji bez sklepow)
            val list = DEFAULT_SHOPS.map { Shop(newId(c), it) }
            val first = list.first().id
            val ed = p.edit()
            // przeniesienie listy z poprzedniej wersji aplikacji do pierwszego sklepu
            p.getString("items", null)?.let { ed.putString(itemsKey(first), it).remove("items") }
            p.getString("freq", null)?.let { ed.putString(freqKey(first), it).remove("freq") }
            ed.putString("shops", shopsToJson(list)).putLong("current", first).apply()
            return list.toMutableList()
        }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Shop(o.getLong("id"), o.getString("name"))
        }.toMutableList()
    }

    private fun shopsToJson(list: List<Shop>): String {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name)) }
        return arr.toString()
    }

    private fun saveShops(c: Context, list: List<Shop>) {
        prefs(c).edit().putString("shops", shopsToJson(list)).apply()
        ListWidgetProvider.refreshAll(c)
    }

    fun currentShopId(c: Context): Long {
        val list = shops(c)
        val id = prefs(c).getLong("current", -1L)
        return if (list.any { it.id == id }) id else list.first().id
    }

    fun currentShop(c: Context): Shop {
        val id = currentShopId(c)
        return shops(c).first { it.id == id }
    }

    fun setCurrent(c: Context, id: Long) {
        prefs(c).edit().putLong("current", id).apply()
        ListWidgetProvider.refreshAll(c)
    }

    /** Przelacza na nastepny sklep (przycisk w widzecie). */
    fun nextShop(c: Context) {
        val list = shops(c)
        val i = list.indexOfFirst { it.id == currentShopId(c) }
        setCurrent(c, list[(i + 1) % list.size].id)
    }

    fun shopColor(c: Context, id: Long): Int {
        val i = shops(c).indexOfFirst { it.id == id }.coerceAtLeast(0)
        return Color.parseColor(PALETTE[i % PALETTE.size])
    }

    /** Zwraca id nowego sklepu albo null, gdy nazwa pusta lub juz istnieje. */
    fun addShop(c: Context, raw: String): Long? {
        val name = normalize(raw)
        if (name.isBlank()) return null
        val list = shops(c)
        if (list.any { it.name.equals(name, ignoreCase = true) }) return null
        val shop = Shop(newId(c), name)
        list.add(shop)
        saveShops(c, list)
        return shop.id
    }

    fun renameShop(c: Context, id: Long, raw: String) {
        val name = normalize(raw)
        if (name.isBlank()) return
        val list = shops(c)
        list.find { it.id == id }?.name = name
        saveShops(c, list)
    }

    /** Usuwa sklep razem z jego lista. Nie pozwala usunac ostatniego sklepu. */
    fun deleteShop(c: Context, id: Long): Boolean {
        val list = shops(c)
        if (list.size <= 1) return false
        list.removeAll { it.id == id }
        prefs(c).edit().remove(itemsKey(id)).remove(freqKey(id)).apply()
        if (currentShopId(c) == id || prefs(c).getLong("current", -1L) == id) {
            prefs(c).edit().putLong("current", list.first().id).apply()
        }
        saveShops(c, list)
        return true
    }

    // =====================================================================
    // LISTA ZAKUPOW (osobna dla kazdego sklepu)
    // =====================================================================

    private fun itemsKey(shopId: Long) = "items_$shopId"
    private fun freqKey(shopId: Long) = "freq_$shopId"

    fun items(c: Context, shopId: Long = currentShopId(c)): MutableList<Item> {
        val arr = JSONArray(prefs(c).getString(itemsKey(shopId), "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Item(o.getLong("id"), o.getString("name"), o.getBoolean("checked"))
        }.toMutableList()
    }

    /** Najpierw to, co do kupienia, potem to, co juz w koszyku. */
    fun sorted(c: Context, shopId: Long = currentShopId(c)): List<Item> =
        items(c, shopId).sortedBy { it.checked }

    fun countToBuy(c: Context, shopId: Long): Int = items(c, shopId).count { !it.checked }

    private fun save(c: Context, shopId: Long, list: List<Item>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("checked", it.checked))
        }
        prefs(c).edit().putString(itemsKey(shopId), arr.toString()).apply()
        ListWidgetProvider.refreshAll(c)
    }

    /** W ktorym sklepie jest pozycja o tym id (id sa unikalne dla calej aplikacji). */
    private fun shopOf(c: Context, itemId: Long): Long? =
        shops(c).firstOrNull { s -> items(c, s.id).any { it.id == itemId } }?.id

    /** Zwraca true, gdy produkt zostal dodany jako nowa pozycja. */
    fun add(c: Context, raw: String, shopId: Long = currentShopId(c)): Boolean {
        val name = normalize(raw)
        if (name.isBlank()) return false
        val list = items(c, shopId)
        val existing = list.find { it.name.equals(name, ignoreCase = true) }
        if (existing != null) {
            if (existing.checked) {
                existing.checked = false
                save(c, shopId, list)
            }
            return false
        }
        list.add(Item(newId(c), name, false))
        save(c, shopId, list)
        bumpFreq(c, shopId, name)
        return true
    }

    fun toggle(c: Context, itemId: Long) {
        val sid = shopOf(c, itemId) ?: return
        val list = items(c, sid)
        list.find { it.id == itemId }?.let { it.checked = !it.checked }
        save(c, sid, list)
    }

    fun rename(c: Context, itemId: Long, newName: String) {
        val name = normalize(newName)
        if (name.isBlank()) return
        val sid = shopOf(c, itemId) ?: return
        val list = items(c, sid)
        list.find { it.id == itemId }?.name = name
        save(c, sid, list)
    }

    fun remove(c: Context, itemId: Long) {
        val sid = shopOf(c, itemId) ?: return
        save(c, sid, items(c, sid).filter { it.id != itemId })
    }

    /** Przenosi produkt do listy innego sklepu. */
    fun moveItem(c: Context, itemId: Long, targetShopId: Long) {
        val sid = shopOf(c, itemId) ?: return
        if (sid == targetShopId) return
        val item = items(c, sid).find { it.id == itemId } ?: return
        save(c, sid, items(c, sid).filter { it.id != itemId })
        add(c, item.name, targetShopId)
    }

    fun removeChecked(c: Context): Int {
        val sid = currentShopId(c)
        val list = items(c, sid)
        val left = list.filter { !it.checked }
        save(c, sid, left)
        return list.size - left.size
    }

    fun clearAll(c: Context) = save(c, currentShopId(c), emptyList())

    // =====================================================================
    // CZESTO KUPOWANE (osobno dla kazdego sklepu)
    // =====================================================================

    private fun freq(c: Context, shopId: Long) =
        JSONObject(prefs(c).getString(freqKey(shopId), "{}"))

    private fun saveFreq(c: Context, shopId: Long, o: JSONObject) =
        prefs(c).edit().putString(freqKey(shopId), o.toString()).apply()

    private fun entry(o: JSONObject, name: String): JSONObject {
        val k = name.lowercase()
        return o.optJSONObject(k) ?: JSONObject()
            .put("name", name).put("count", 0).put("fav", false)
            .also { o.put(k, it) }
    }

    private fun bumpFreq(c: Context, shopId: Long, name: String) {
        val o = freq(c, shopId)
        val e = entry(o, name)
        e.put("count", e.optInt("count") + 1)
        saveFreq(c, shopId, o)
    }

    fun favorites(c: Context): Set<String> {
        val o = freq(c, currentShopId(c))
        val res = mutableSetOf<String>()
        o.keys().forEach { k -> if (o.getJSONObject(k).optBoolean("fav")) res.add(k) }
        return res
    }

    fun toggleFav(c: Context, name: String) {
        val sid = currentShopId(c)
        val o = freq(c, sid)
        val e = entry(o, name)
        e.put("fav", !e.optBoolean("fav"))
        saveFreq(c, sid, o)
    }

    fun forget(c: Context, name: String) {
        val sid = currentShopId(c)
        val o = freq(c, sid)
        o.remove(name.lowercase())
        saveFreq(c, sid, o)
    }

    /** Podpowiedzi: ulubione (gwiazdka) + kupione co najmniej 2 razy, ktorych teraz nie ma na liscie. */
    fun suggestions(c: Context): List<Pair<String, Boolean>> {
        val sid = currentShopId(c)
        val onList = items(c, sid).filter { !it.checked }.map { it.name.lowercase() }.toSet()
        val o = freq(c, sid)
        val res = mutableListOf<Triple<String, Int, Boolean>>()
        o.keys().forEach { k ->
            val e = o.getJSONObject(k)
            val fav = e.optBoolean("fav")
            val count = e.optInt("count")
            if (k !in onList && (fav || count >= 2)) res.add(Triple(e.getString("name"), count, fav))
        }
        return res.sortedWith(compareByDescending<Triple<String, Int, Boolean>> { it.third }
            .thenByDescending { it.second })
            .take(30)
            .map { it.first to it.third }
    }
}

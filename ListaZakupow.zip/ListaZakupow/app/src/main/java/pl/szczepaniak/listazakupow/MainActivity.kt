package pl.szczepaniak.listazakupow

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_FOCUS_ADD = "focus_add"
    }

    private lateinit var input: EditText
    private lateinit var shopChips: ChipGroup
    private lateinit var chips: ChipGroup
    private lateinit var freqLabel: TextView
    private lateinit var counter: TextView
    private lateinit var empty: TextView
    private lateinit var header: TextView
    private val adapter = ItemsAdapter()
    private var photoUri: Uri? = null

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) photoUri?.let { recognize(it) }
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let { recognize(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        photoUri = savedInstanceState?.getString("photoUri")?.let { Uri.parse(it) }

        input = findViewById(R.id.input)
        shopChips = findViewById(R.id.shopChips)
        chips = findViewById(R.id.chips)
        freqLabel = findViewById(R.id.freqLabel)
        counter = findViewById(R.id.counter)
        empty = findViewById(R.id.empty)
        header = findViewById(R.id.header)

        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<View>(R.id.btnAdd).setOnClickListener { addFromInput() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { addFromInput(); true } else false
        }
        findViewById<View>(R.id.btnPhoto).setOnClickListener { openCamera() }
        findViewById<View>(R.id.btnGallery).setOnClickListener { pickImage.launch("image/*") }
        findViewById<View>(R.id.btnClear).setOnClickListener { finishShopping() }
        findViewById<View>(R.id.btnClear).setOnLongClickListener { confirmClearAll(); true }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refresh() // np. po odhaczeniu czegos albo zmianie sklepu w widzecie
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        photoUri?.let { outState.putString("photoUri", it.toString()) }
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_FOCUS_ADD, false) == true) {
            input.requestFocus()
            input.post {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Pole tekstowe z marginesami do okienek dialogowych. */
    private fun dialogInput(text: String, hint: String): Pair<EditText, View> {
        val edit = EditText(this).apply {
            setText(text)
            setSelection(text.length)
            this.hint = hint
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(edit)
        }
        return edit to box
    }

    // ---------- SKLEPY ----------

    private fun addShopDialog() {
        val (edit, box) = dialogInput("", "np. Auchan, Kaufland, apteka")
        MaterialAlertDialogBuilder(this)
            .setTitle("Nowy sklep")
            .setView(box)
            .setPositiveButton("Dodaj") { _, _ ->
                val id = Store.addShop(this, edit.text.toString())
                if (id == null) toast("Pusta nazwa albo taki sklep już jest")
                else { Store.setCurrent(this, id); refresh() }
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun shopMenu(shop: Shop) {
        MaterialAlertDialogBuilder(this)
            .setTitle(shop.name)
            .setItems(arrayOf("Zmień nazwę", "Usuń sklep (razem z jego listą)")) { _, which ->
                if (which == 0) renameShopDialog(shop) else confirmDeleteShop(shop)
            }
            .show()
    }

    private fun renameShopDialog(shop: Shop) {
        val (edit, box) = dialogInput(shop.name, "Nazwa sklepu")
        MaterialAlertDialogBuilder(this)
            .setTitle("Zmień nazwę sklepu")
            .setView(box)
            .setPositiveButton("Zapisz") { _, _ ->
                Store.renameShop(this, shop.id, edit.text.toString()); refresh()
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun confirmDeleteShop(shop: Shop) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Usunąć sklep ${shop.name}?")
            .setMessage("Zniknie też lista zakupów i podpowiedzi dla tego sklepu.")
            .setPositiveButton("Usuń") { _, _ ->
                if (!Store.deleteShop(this, shop.id)) toast("Musi zostać przynajmniej jeden sklep")
                refresh()
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    // ---------- DODAWANIE ----------

    private fun addFromInput() {
        val text = input.text.toString()
        if (text.isBlank()) return
        // mozna wpisac kilka produktow naraz, oddzielonych przecinkiem
        text.split(",", ";", "\n").forEach { Store.add(this, it) }
        input.setText("")
        refresh()
    }

    // ---------- ZDJECIE LISTY ----------

    private fun openCamera() {
        val dir = File(cacheDir, "images").apply { mkdirs() }
        val file = File(dir, "lista.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        photoUri = uri
        try {
            takePicture.launch(uri)
        } catch (e: ActivityNotFoundException) {
            toast("Brak aplikacji aparatu")
        }
    }

    private fun recognize(uri: Uri) {
        val image = try {
            InputImage.fromFilePath(this, uri)
        } catch (e: Exception) {
            toast("Nie mogę otworzyć zdjęcia"); return
        }
        toast("Odczytuję listę…")
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { result ->
                val lines = result.textBlocks
                    .flatMap { it.lines }
                    .map { cleanLine(it.text) }
                    .filter { it.length >= 2 }
                    .distinctBy { it.lowercase() }
                if (lines.isEmpty()) toast("Nie rozpoznano tekstu – spróbuj wyraźniejsze zdjęcie")
                else showPicker(lines)
            }
            .addOnFailureListener { toast("Błąd odczytu: ${it.message}") }
    }

    /** Usuwa myslniki, kropki, numery na poczatku linii itp. */
    private fun cleanLine(s: String): String =
        s.trim()
            .replace(Regex("^[\\-–—•*·+\\d.)\\]\\s]+"), "")
            .replace(Regex("[\\s.,;:]+$"), "")
            .trim()

    private fun showPicker(lines: List<String>) {
        val arr = lines.toTypedArray()
        val checked = BooleanArray(arr.size) { true }
        val shop = Store.currentShop(this)
        MaterialAlertDialogBuilder(this)
            .setTitle("Dodaj do: ${shop.name}\n(odznacz błędnie odczytane)")
            .setMultiChoiceItems(arr, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Dodaj zaznaczone") { _, _ ->
                var n = 0
                arr.forEachIndexed { i, s -> if (checked[i] && Store.add(this, s)) n++ }
                refresh()
                toast("Dodano: $n")
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    // ---------- ZAKONCZENIE ZAKUPOW ----------

    private fun finishShopping() {
        val n = Store.removeChecked(this)
        refresh()
        toast(if (n == 0) "Nic nie jest jeszcze w koszyku" else "Usunięto z listy: $n")
    }

    private fun confirmClearAll() {
        val shop = Store.currentShop(this)
        MaterialAlertDialogBuilder(this)
            .setTitle("Wyczyścić całą listę – ${shop.name}?")
            .setMessage("Usunie wszystkie pozycje z tego sklepu. Pamięć często kupowanych zostaje.")
            .setPositiveButton("Wyczyść") { _, _ -> Store.clearAll(this); refresh() }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    // ---------- ODSWIEZANIE ----------

    private fun refresh() {
        val shop = Store.currentShop(this)
        val shopColor = Store.shopColor(this, shop.id)
        header.text = "🛒  ${shop.name}"
        header.setBackgroundColor(shopColor)
        window.statusBarColor = shopColor
        input.hint = "Dodaj do: ${shop.name} (kilka – po przecinku)"

        // zakladki sklepow
        shopChips.removeAllViews()
        Store.shops(this).forEach { s ->
            val selected = s.id == shop.id
            val color = Store.shopColor(this, s.id)
            val n = Store.countToBuy(this, s.id)
            shopChips.addView(Chip(this).apply {
                text = if (n > 0) "${s.name} ($n)" else s.name
                chipBackgroundColor = ColorStateList.valueOf(
                    if (selected) color else Color.parseColor("#FFFFFF")
                )
                chipStrokeColor = ColorStateList.valueOf(color)
                chipStrokeWidth = dp(1).toFloat()
                setTextColor(if (selected) Color.WHITE else color)
                setOnClickListener { Store.setCurrent(this@MainActivity, s.id); refresh() }
                setOnLongClickListener { shopMenu(s); true }
            })
        }
        shopChips.addView(Chip(this).apply {
            text = "+ Sklep"
            chipBackgroundColor = ColorStateList.valueOf(Color.parseColor("#E8F5E9"))
            setTextColor(Color.parseColor("#2E7D32"))
            setOnClickListener { addShopDialog() }
        })

        // lista
        val items = Store.sorted(this)
        adapter.data = items
        adapter.favs = Store.favorites(this)
        adapter.notifyDataSetChanged()

        val toBuy = items.count { !it.checked }
        val inCart = items.size - toBuy
        counter.text = "${shop.name}:  do kupienia $toBuy   •   w koszyku $inCart"
        counter.setTextColor(shopColor)
        empty.text = "Lista dla sklepu ${shop.name} jest pusta.\n" +
            "Wpisz produkt albo zrób zdjęcie papierowej listy."
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE

        // podpowiedzi
        chips.removeAllViews()
        val sugg = Store.suggestions(this)
        freqLabel.visibility = if (sugg.isEmpty()) View.GONE else View.VISIBLE
        chips.visibility = freqLabel.visibility
        sugg.forEach { (name, fav) ->
            chips.addView(Chip(this).apply {
                text = if (fav) "★ $name" else "+ $name"
                setOnClickListener { Store.add(this@MainActivity, name); refresh() }
                setOnLongClickListener { suggestionMenu(name, fav); true }
            })
        }
    }

    private fun suggestionMenu(name: String, fav: Boolean) {
        val options = arrayOf(
            if (fav) "Usuń gwiazdkę (ulubione)" else "Dodaj gwiazdkę (ulubione)",
            "Nie podpowiadaj więcej"
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(name)
            .setItems(options) { _, which ->
                if (which == 0) Store.toggleFav(this, name) else Store.forget(this, name)
                refresh()
            }
            .show()
    }

    private fun itemMenu(item: Item) {
        MaterialAlertDialogBuilder(this)
            .setTitle(item.name)
            .setItems(arrayOf("Popraw nazwę", "Przenieś do innego sklepu")) { _, which ->
                if (which == 0) renameDialog(item) else moveDialog(item)
            }
            .show()
    }

    private fun renameDialog(item: Item) {
        val (edit, box) = dialogInput(item.name, "Nazwa produktu")
        MaterialAlertDialogBuilder(this)
            .setTitle("Popraw nazwę")
            .setView(box)
            .setPositiveButton("Zapisz") { _, _ ->
                Store.rename(this, item.id, edit.text.toString()); refresh()
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun moveDialog(item: Item) {
        val current = Store.currentShopId(this)
        val others = Store.shops(this).filter { it.id != current }
        if (others.isEmpty()) { toast("Brak innych sklepów"); return }
        MaterialAlertDialogBuilder(this)
            .setTitle("Przenieś „${item.name}” do:")
            .setItems(others.map { it.name }.toTypedArray()) { _, which ->
                Store.moveItem(this, item.id, others[which].id)
                toast("Przeniesiono do: ${others[which].name}")
                refresh()
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    // ---------- ADAPTER LISTY ----------

    inner class ItemsAdapter : RecyclerView.Adapter<ItemsAdapter.VH>() {
        var data: List<Item> = emptyList()
        var favs: Set<String> = emptySet()

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val check: CheckBox = v.findViewById(R.id.check)
            val name: TextView = v.findViewById(R.id.name)
            val star: TextView = v.findViewById(R.id.star)
            val del: TextView = v.findViewById(R.id.del)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false))

        override fun getItemCount() = data.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = data[position]
            val ctx = this@MainActivity
            h.check.isChecked = item.checked
            h.name.text = item.name
            h.name.paintFlags = if (item.checked)
                h.name.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            else
                h.name.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            h.itemView.alpha = if (item.checked) 0.55f else 1f
            h.star.text = if (item.name.lowercase() in favs) "★" else "☆"

            val toggle = View.OnClickListener { Store.toggle(ctx, item.id); refresh() }
            h.itemView.setOnClickListener(toggle)
            h.check.setOnClickListener(toggle)
            h.itemView.setOnLongClickListener { itemMenu(item); true }
            h.star.setOnClickListener { Store.toggleFav(ctx, item.name); refresh() }
            h.del.setOnClickListener { Store.remove(ctx, item.id); refresh() }
        }
    }
}

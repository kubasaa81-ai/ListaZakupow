package pl.szczepaniak.listazakupow

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StrikethroughSpan
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class ListWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    class Factory(private val ctx: Context) : RemoteViewsFactory {
        private var items: List<Item> = emptyList()

        override fun onCreate() {}
        override fun onDataSetChanged() { items = Store.sorted(ctx) }
        override fun onDestroy() {}
        override fun getCount() = items.size
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun hasStableIds() = true
        override fun getItemId(position: Int): Long = items.getOrNull(position)?.id ?: position.toLong()

        override fun getViewAt(position: Int): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_item)
            val item = items.getOrNull(position) ?: return rv

            val text: CharSequence = if (item.checked) {
                SpannableString(item.name).apply {
                    setSpan(StrikethroughSpan(), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            } else item.name
            rv.setTextViewText(R.id.item_text, text)
            rv.setTextColor(
                R.id.item_text,
                if (item.checked) Color.parseColor("#9E9E9E") else Color.parseColor("#1B1B1B")
            )
            rv.setImageViewResource(
                R.id.item_check,
                if (item.checked) R.drawable.ic_box_checked else R.drawable.ic_box_empty
            )
            rv.setOnClickFillInIntent(
                R.id.item_root,
                Intent().putExtra(ListWidgetProvider.EXTRA_ID, item.id)
            )
            return rv
        }
    }
}
